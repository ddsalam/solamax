@echo off
cd /d "%~dp0"
node solamax-agent.cjs --config config.local.json
